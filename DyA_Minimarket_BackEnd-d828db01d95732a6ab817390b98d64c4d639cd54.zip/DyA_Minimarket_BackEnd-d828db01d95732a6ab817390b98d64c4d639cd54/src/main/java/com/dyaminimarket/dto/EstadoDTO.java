package com.dyaminimarket.dto;


public class EstadoDTO {
    private Integer id;
    private String estado;
    private String detalleEstado;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDetalleEstado() {
		return detalleEstado;
	}
	public void setDetalleEstado(String detalleEstado) {
		this.detalleEstado = detalleEstado;
	}

}
