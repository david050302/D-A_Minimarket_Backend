package com.dyaminimarket.dto;

public class CategoriaDTO {

	private Integer id;
	private String nombreCategoria;
	private String detalleCategoria;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombreCategoria() {
		return nombreCategoria;
	}
	public void setNombreCategoria(String nombreCategoria) {
		this.nombreCategoria = nombreCategoria;
	}
	public String getDetalleCategoria() {
		return detalleCategoria;
	}
	public void setDetalleCategoria(String detalleCategoria) {
		this.detalleCategoria = detalleCategoria;
	}
	
	
	
}
