package com.dyaminimarket.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dyaminimarket.models.DetalleCotizacion;

public interface DetalleCotizacionRepository extends JpaRepository<DetalleCotizacion, Integer> {

}
